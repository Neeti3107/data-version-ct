This folder contains notebooks and datasets related to model monitoring.


### Model Monitoring

[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/manaranjanp/mlopsv2/blob/main/monitor/Model%20Monitoring.ipynb)
